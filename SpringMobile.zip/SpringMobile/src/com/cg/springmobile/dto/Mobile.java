package com.cg.springmobile.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="mobile_mgt")
public class Mobile 
{
	@Id
	@Column(name="mob_id")
	private int mobId;
	@Column(name="mob_name")
	private String mobName;
	@Column(name="mob_price")
	private double price;
	@Column(name="mob_model")
	private String mobModel;
	
	public int getMobId() {
		return mobId;
	}
	public void setMobId(int mobId) {
		this.mobId = mobId;
	}
	public String getMobName() {
		return mobName;
	}
	public void setMobName(String mobName) {
		this.mobName = mobName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getMobModel() {
		return mobModel;
	}
	public void setMobModel(String mobModel) {
		this.mobModel = mobModel;
	}
	
	
}
