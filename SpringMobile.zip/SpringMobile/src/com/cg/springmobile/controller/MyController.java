package com.cg.springmobile.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmobile.dto.Mobile;
import com.cg.springmobile.service.IMobileService;


@Controller
public class MyController 
{
	@Autowired
	IMobileService mobileservice;
	
	
	
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		return "home";
	}
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addMobile(@ModelAttribute("my") Mobile mob,
			Map<String, Object> model)
	{
		List<String> myMod= new ArrayList<>();
		myMod.add("Samsung GT-X");
		myMod.add("Iphone X");
		myMod.add("Nokia 3550");
		
		model.put("modss", myMod); //model is the name of map which is used to transfer the value to addemployee
									//we could have also used session or request to send data but we used map
		
		return "addmobile";
	}
	
	@RequestMapping(value="insertdata",method=RequestMethod.POST)
	public String insertMobile(@ModelAttribute("my") Mobile mob)
	{
		
		mobileservice.addMobileData(mob);
		return "success";
	}
	
	@RequestMapping(value="show",method=RequestMethod.GET)
	public ModelAndView showAllEmployee()
	{
		//we have to return data and view so return type.
		
		List<Mobile> myAllData=mobileservice.showAllMobile();
		return new ModelAndView("showall", "temp", myAllData);
		
	}
}
